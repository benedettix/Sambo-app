const mysqlConfig = {
  host: "localhost",
  user: "root",
  password: "",
  database: "mydb",
};
// XRFufX6&IFHb&yl6uwq* lozinka od sajta
// a>PH3#q!Ug8~&2#3 lozinka od database
module.exports = mysqlConfig;
